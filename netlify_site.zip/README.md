# Netlify 部署文件夹

这个文件夹包含：
- `index.html` - 招聘页面主文件

## 如何使用

1. 打开 https://app.netlify.com/drop
2. 将整个 `netlify_deploy` 文件夹拖进去
3. 等待部署完成
4. 获得您的网站链接！

## 注意

确保文件夹内只有 `index.html` 文件（Netlify会识别它）

